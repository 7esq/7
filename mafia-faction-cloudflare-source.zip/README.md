# Mafia — Cloudflare

Source do site da Mafia, preparada para publicar como Cloudflare Worker com
assets estáticos e banco D1.

## Antes de começar

- Node.js `>=22.13.0`
- Uma conta Cloudflare gratuita
- Wrangler autenticado com essa conta

Este pacote não contém nenhuma chave real, token ou segredo. A chave do
proprietário deve ser criada por você depois que o D1 estiver configurado.

## Publicação rápida

Abra o terminal dentro desta pasta e execute:

```bash
npm install
npx wrangler login
npx wrangler d1 create mafia-faction-db
```

O comando do D1 mostrará um `database_id`. Abra `wrangler.jsonc` e troque o
valor `00000000-0000-4000-8000-000000000000` pelo ID retornado.

Aplique as tabelas no banco remoto:

```bash
npx wrangler d1 migrations apply DB --remote
```

Crie os segredos quando o terminal solicitar os valores:

```bash
npx wrangler secret put AUTH_SECRET
npx wrangler secret put ADMIN_OWNER_KEY
```

Use valores aleatórios longos nos dois comandos. Não coloque esses valores no
Git, no ZIP ou em arquivos públicos.

Agora publique:

```bash
npm run deploy:cloudflare
```

O endereço ficará parecido com:

```text
https://mafia-faction.<seu-subdominio>.workers.dev
```

Depois do primeiro deploy, defina a origem pública usada nos links da
dashboard. Troque o valor pelo endereço real do Worker:

```bash
npx wrangler secret put PUBLIC_SITE_URL
```

O link privado do proprietário terá este formato:

```text
https://SEU_WORKER.workers.dev/admin/access?key=SUA_ADMIN_OWNER_KEY
```

Mantenha esse link e a chave em sigilo. O proprietário pode entrar na aba de
acessos da dashboard e criar chaves de uso único para outras pessoas.

## Desenvolvimento local

```bash
npm run dev
```

Para fazer uma verificação de build em ambientes com Bash e GNU `timeout`:

```bash
npm run build
```

## Observações

- O arquivo `wrangler.jsonc` já declara o Worker, os assets e o binding D1.
- As migrações estão em `drizzle/` e devem ser aplicadas ao D1 remoto antes do
  primeiro uso do painel.
- O projeto usa apenas autenticação por chave; não depende de Discord ou
  Google.

Documentação oficial: [Vinext no Cloudflare](https://github.com/cloudflare/vinext),
[migrações D1](https://developers.cloudflare.com/d1/reference/migrations/) e
[rotas workers.dev](https://developers.cloudflare.com/workers/configuration/routing/workers-dev/).
