import { and, desc, eq, gt, isNull } from "drizzle-orm";
import { env } from "cloudflare:workers";

import { getDb } from "@/db";
import {
  adminAccessKeys,
  adminLogs,
  adminSessions,
  adminUsers,
  webhooks,
} from "@/db/schema";

export type AuthProvider = "key";

export type AdminIdentity = {
  id: string;
  provider: AuthProvider;
  providerId: string;
  email: string | null;
  displayName: string;
  enabled: boolean;
  lastLoginAt: string | null;
  isOwner: boolean;
};

export type AccessKeyRecord = {
  id: string;
  label: string;
  createdBy: string;
  createdAt: string;
  expiresAt: string;
  usedAt: string | null;
  usedBy: string | null;
  revokedAt: string | null;
};

type RuntimeEnv = Record<string, string | undefined>;

const SESSION_COOKIE = "mafia_admin_session";
const SESSION_MAX_AGE = 60 * 60 * 24 * 7;
const OWNER_PROVIDER_ID = "owner";

function runtimeEnv(): RuntimeEnv {
  return env as unknown as RuntimeEnv;
}

export function getEnv(name: string): string | undefined {
  return runtimeEnv()[name]?.trim() || undefined;
}

export function getAuthAvailability() {
  return {
    key: Boolean(getEnv("AUTH_SECRET") && getEnv("ADMIN_OWNER_KEY")),
    encryption: Boolean(getEnv("AUTH_SECRET")),
  };
}

export function getCookie(cookieHeader: string | null, name: string): string | null {
  if (!cookieHeader) return null;
  const match = cookieHeader.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]*)"));
  if (!match) return null;
  try {
    return decodeURIComponent(match[1]);
  } catch {
    return null;
  }
}

function cookieHeader(name: string, value: string, maxAge: number, path: string): string {
  return name + "=" + encodeURIComponent(value) + "; Max-Age=" + maxAge + "; Path=" + path + "; HttpOnly; Secure; SameSite=Lax";
}

export function sessionCookie(token: string): string {
  return cookieHeader(SESSION_COOKIE, token, SESSION_MAX_AGE, "/");
}

export function clearSessionCookie(): string {
  return cookieHeader(SESSION_COOKIE, "", 0, "/");
}

function base64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

function randomToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return base64Url(bytes);
}

async function sha256(value: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return base64Url(new Uint8Array(digest));
}

async function hashAccessKey(value: string): Promise<string> {
  return sha256("mafia-admin-key:" + value);
}

async function keysMatch(candidate: string, expected: string): Promise<boolean> {
  const [left, right] = await Promise.all([sha256(candidate), sha256(expected)]);
  let mismatch = left.length === right.length ? 0 : 1;
  const length = Math.max(left.length, right.length);
  for (let index = 0; index < length; index += 1) {
    const leftCode = index < left.length ? left.charCodeAt(index) : 0;
    const rightCode = index < right.length ? right.charCodeAt(index) : 0;
    mismatch |= leftCode ^ rightCode;
  }
  return mismatch === 0;
}

function isConfiguredOwner(provider: AuthProvider, providerId: string): boolean {
  return provider === "key" && providerId === OWNER_PROVIDER_ID;
}

export function isAdminOwner(
  user: Pick<AdminIdentity, "provider" | "providerId"> &
    Partial<Pick<AdminIdentity, "isOwner">>,
): boolean {
  return Boolean(user.isOwner) || isConfiguredOwner(user.provider, user.providerId);
}

function identityFromRow(row: {
  id: string;
  providerId: string;
  email: string | null;
  displayName: string;
  enabled: boolean;
  lastLoginAt: string | null;
}): AdminIdentity {
  return {
    id: row.id,
    provider: "key",
    providerId: row.providerId,
    email: row.email,
    displayName: row.displayName,
    enabled: row.enabled,
    lastLoginAt: row.lastLoginAt,
    isOwner: isConfiguredOwner("key", row.providerId),
  };
}

export async function getAdminUserFromCookie(cookieHeaderValue: string | null): Promise<AdminIdentity | null> {
  const sessionToken = getCookie(cookieHeaderValue, SESSION_COOKIE);
  if (!sessionToken) return null;

  try {
    const tokenHash = await sha256(sessionToken);
    const [row] = await getDb()
      .select({
        id: adminUsers.id,
        provider: adminUsers.provider,
        providerId: adminUsers.providerId,
        email: adminUsers.email,
        displayName: adminUsers.displayName,
        enabled: adminUsers.enabled,
        lastLoginAt: adminUsers.lastLoginAt,
        expiresAt: adminSessions.expiresAt,
      })
      .from(adminSessions)
      .innerJoin(adminUsers, eq(adminUsers.id, adminSessions.adminUserId))
      .where(and(eq(adminSessions.tokenHash, tokenHash), eq(adminUsers.enabled, true)))
      .limit(1);

    if (!row || row.provider !== "key" || new Date(row.expiresAt).getTime() <= Date.now()) return null;
    return identityFromRow(row);
  } catch {
    return null;
  }
}

export async function createAdminSession(adminUserId: string): Promise<string> {
  const token = randomToken();
  const tokenHash = await sha256(token);
  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE * 1000).toISOString();
  await getDb().insert(adminSessions).values({ tokenHash, adminUserId, expiresAt });
  return token;
}

export async function deleteAdminSession(cookieHeaderValue: string | null): Promise<void> {
  const sessionToken = getCookie(cookieHeaderValue, SESSION_COOKIE);
  if (!sessionToken) return;
  await getDb().delete(adminSessions).where(eq(adminSessions.tokenHash, await sha256(sessionToken)));
}

async function upsertKeyIdentity(providerId: string, displayName: string): Promise<AdminIdentity> {
  const now = new Date().toISOString();
  const [existing] = await getDb()
    .select({
      id: adminUsers.id,
      providerId: adminUsers.providerId,
      email: adminUsers.email,
      displayName: adminUsers.displayName,
      enabled: adminUsers.enabled,
      lastLoginAt: adminUsers.lastLoginAt,
    })
    .from(adminUsers)
    .where(and(eq(adminUsers.provider, "key"), eq(adminUsers.providerId, providerId)))
    .limit(1);

  if (existing) {
    const [updated] = await getDb()
      .update(adminUsers)
      .set({ displayName, enabled: true, lastLoginAt: now, updatedAt: now })
      .where(eq(adminUsers.id, existing.id))
      .returning({
        id: adminUsers.id,
        providerId: adminUsers.providerId,
        email: adminUsers.email,
        displayName: adminUsers.displayName,
        enabled: adminUsers.enabled,
        lastLoginAt: adminUsers.lastLoginAt,
      });
    if (!updated) throw new Error("Admin identity update failed");
    return identityFromRow(updated);
  }

  const [created] = await getDb()
    .insert(adminUsers)
    .values({
      id: crypto.randomUUID(),
      provider: "key",
      providerId,
      email: null,
      displayName,
      enabled: true,
      updatedAt: now,
      lastLoginAt: now,
    })
    .returning({
      id: adminUsers.id,
      providerId: adminUsers.providerId,
      email: adminUsers.email,
      displayName: adminUsers.displayName,
      enabled: adminUsers.enabled,
      lastLoginAt: adminUsers.lastLoginAt,
    });
  if (!created) throw new Error("Admin identity creation failed");
  return identityFromRow(created);
}

export async function redeemAdminKey(rawKey: string): Promise<{ admin: AdminIdentity; token: string } | null> {
  const value = rawKey.trim();
  if (value.length < 16) return null;

  const ownerKey = getEnv("ADMIN_OWNER_KEY");
  if (ownerKey && (await keysMatch(value, ownerKey))) {
    const admin = await upsertKeyIdentity(OWNER_PROVIDER_ID, "Mafia Owner");
    const token = await createAdminSession(admin.id);
    await writeAdminLog(admin.id, "key_login", "owner", "permanent_owner_key", "success");
    return { admin, token };
  }

  const keyHash = await hashAccessKey(value);
  const now = new Date().toISOString();
  const [claimed] = await getDb()
    .update(adminAccessKeys)
    .set({ usedAt: now })
    .where(
      and(
        eq(adminAccessKeys.keyHash, keyHash),
        isNull(adminAccessKeys.usedAt),
        isNull(adminAccessKeys.revokedAt),
        gt(adminAccessKeys.expiresAt, now),
      ),
    )
    .returning({ id: adminAccessKeys.id, label: adminAccessKeys.label });

  if (!claimed) return null;

  const admin = await upsertKeyIdentity("invite:" + claimed.id, claimed.label);
  await getDb().update(adminAccessKeys).set({ usedBy: admin.id }).where(eq(adminAccessKeys.id, claimed.id));
  const token = await createAdminSession(admin.id);
  await writeAdminLog(admin.id, "key_login", claimed.label, "single_use_key", "success");
  return { admin, token };
}

export function redirectToAdmin(request: Request, error?: string): Response {
  const url = new URL("/admin", request.url);
  if (error) url.searchParams.set("error", error);
  return Response.redirect(url.toString(), 302);
}

export async function requireAdmin(request: Request): Promise<{ user: AdminIdentity | null; response: Response | null }> {
  const user = await getAdminUserFromCookie(request.headers.get("cookie"));
  if (user) return { user, response: null };
  return { user: null, response: Response.json({ error: "Admin authentication required." }, { status: 401 }) };
}

export async function requireAdminOwner(request: Request): Promise<{ user: AdminIdentity | null; response: Response | null }> {
  const auth = await requireAdmin(request);
  if (auth.response || !auth.user) return auth;
  if (isAdminOwner(auth.user)) return auth;
  await writeAdminLog(auth.user.id, "owner_action_denied", "access", "owner_only", "denied");
  return { user: auth.user, response: Response.json({ error: "Somente o proprietário pode alterar administradores." }, { status: 403 }) };
}

export async function writeAdminLog(
  actorId: string | null,
  action: string,
  target: string | null,
  detail: string,
  status: "success" | "error" | "denied" = "success",
): Promise<void> {
  try {
    await getDb().insert(adminLogs).values({ id: crypto.randomUUID(), actorId, action, target, detail, status });
  } catch {
    // Logging must not turn a completed admin action into a failed request.
  }
}

async function encryptionKey(): Promise<CryptoKey> {
  const secret = getEnv("AUTH_SECRET");
  if (!secret) throw new Error("AUTH_SECRET is required");
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret));
  return crypto.subtle.importKey("raw", digest, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function encryptSecret(value: string): Promise<{ ciphertext: string; iv: string }> {
  const iv = new Uint8Array(12);
  crypto.getRandomValues(iv);
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    await encryptionKey(),
    new TextEncoder().encode(value),
  );
  return { ciphertext: base64Url(new Uint8Array(encrypted)), iv: base64Url(iv) };
}

function decodeBase64Url(value: string): Uint8Array {
  const base64 = value.replaceAll("-", "+").replaceAll("_", "/");
  const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4);
  return Uint8Array.from(atob(padded), (char) => char.charCodeAt(0));
}

export async function decryptSecret(ciphertext: string, iv: string): Promise<string> {
  const decrypted = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: decodeBase64Url(iv) },
    await encryptionKey(),
    decodeBase64Url(ciphertext),
  );
  return new TextDecoder().decode(decrypted);
}

export function validateDiscordWebhookUrl(value: string): string | null {
  try {
    const url = new URL(value.trim());
    if (url.protocol !== "https:") return null;
    if (url.hostname !== "discord.com" && url.hostname !== "canary.discord.com") return null;
    if (!/^\/api\/webhooks\/[^/]+\/[^/]+/.test(url.pathname)) return null;
    url.search = "";
    url.hash = "";
    return url.toString();
  } catch {
    return null;
  }
}

export function maskWebhookUrl(value: string): string {
  try {
    const url = new URL(value);
    return url.origin + "/api/webhooks/••••••••/••••••••";
  } catch {
    return "Webhook Discord protegido";
  }
}

export async function createWebhook(input: { name: string; url: string; createdBy: string }) {
  const encrypted = await encryptSecret(input.url);
  const [created] = await getDb()
    .insert(webhooks)
    .values({
      id: crypto.randomUUID(),
      name: input.name,
      urlCiphertext: encrypted.ciphertext,
      urlIv: encrypted.iv,
      createdBy: input.createdBy,
    })
    .returning({ id: webhooks.id, name: webhooks.name, createdAt: webhooks.createdAt });
  return { ...created, maskedUrl: maskWebhookUrl(input.url) };
}

export async function listWebhooks() {
  const rows = await getDb().select().from(webhooks).orderBy(desc(webhooks.createdAt));
  return rows.map((row) => ({
    id: row.id,
    name: row.name,
    maskedUrl: "Webhook Discord protegido",
    createdAt: row.createdAt,
  }));
}

export async function getWebhook(id: string) {
  const [row] = await getDb().select().from(webhooks).where(eq(webhooks.id, id)).limit(1);
  return row ?? null;
}

export async function deleteWebhook(id: string): Promise<void> {
  await getDb().delete(webhooks).where(eq(webhooks.id, id));
}

export async function sendDiscordWebhook(url: string, payload: Record<string, unknown>): Promise<void> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url + "?wait=true", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error("Discord retornou " + response.status);
  } finally {
    clearTimeout(timeout);
  }
}

export async function listAdminUsers() {
  const rows = await getDb()
    .select({
      id: adminUsers.id,
      provider: adminUsers.provider,
      providerId: adminUsers.providerId,
      email: adminUsers.email,
      displayName: adminUsers.displayName,
      enabled: adminUsers.enabled,
      lastLoginAt: adminUsers.lastLoginAt,
    })
    .from(adminUsers)
    .orderBy(desc(adminUsers.updatedAt));
  return rows.map((row) => ({
    ...row,
    isOwner: row.provider === "key" && isConfiguredOwner("key", row.providerId),
  }));
}

export async function listAdminLogs(limit = 40) {
  return getDb().select().from(adminLogs).orderBy(desc(adminLogs.createdAt)).limit(Math.min(Math.max(limit, 1), 100));
}

export async function setAdminUserEnabled(id: string, enabled: boolean) {
  const [updated] = await getDb()
    .update(adminUsers)
    .set({ enabled, updatedAt: new Date().toISOString() })
    .where(eq(adminUsers.id, id))
    .returning({
      id: adminUsers.id,
      provider: adminUsers.provider,
      providerId: adminUsers.providerId,
      email: adminUsers.email,
      displayName: adminUsers.displayName,
      enabled: adminUsers.enabled,
      lastLoginAt: adminUsers.lastLoginAt,
    });
  if (!updated) return null;
  return {
    ...updated,
    isOwner: updated.provider === "key" && isConfiguredOwner("key", updated.providerId),
  };
}

export async function createAdminAccessKey(input: {
  label: string;
  createdBy: string;
  expiresInHours?: number;
}): Promise<AccessKeyRecord & { token: string }> {
  const token = randomToken();
  const id = crypto.randomUUID();
  const hours = Math.min(Math.max(Math.round(input.expiresInHours ?? 24), 1), 168);
  const expiresAt = new Date(Date.now() + hours * 60 * 60 * 1000).toISOString();
  const [created] = await getDb()
    .insert(adminAccessKeys)
    .values({
      id,
      keyHash: await hashAccessKey(token),
      label: input.label,
      createdBy: input.createdBy,
      expiresAt,
    })
    .returning({
      id: adminAccessKeys.id,
      label: adminAccessKeys.label,
      createdBy: adminAccessKeys.createdBy,
      createdAt: adminAccessKeys.createdAt,
      expiresAt: adminAccessKeys.expiresAt,
      usedAt: adminAccessKeys.usedAt,
      usedBy: adminAccessKeys.usedBy,
      revokedAt: adminAccessKeys.revokedAt,
    });
  if (!created) throw new Error("Access key creation failed");
  return { ...created, token };
}

export async function listAdminAccessKeys(): Promise<AccessKeyRecord[]> {
  return getDb()
    .select({
      id: adminAccessKeys.id,
      label: adminAccessKeys.label,
      createdBy: adminAccessKeys.createdBy,
      createdAt: adminAccessKeys.createdAt,
      expiresAt: adminAccessKeys.expiresAt,
      usedAt: adminAccessKeys.usedAt,
      usedBy: adminAccessKeys.usedBy,
      revokedAt: adminAccessKeys.revokedAt,
    })
    .from(adminAccessKeys)
    .orderBy(desc(adminAccessKeys.createdAt));
}

export async function revokeAdminAccessKey(id: string): Promise<boolean> {
  const [revoked] = await getDb()
    .update(adminAccessKeys)
    .set({ revokedAt: new Date().toISOString() })
    .where(and(eq(adminAccessKeys.id, id), isNull(adminAccessKeys.usedAt), isNull(adminAccessKeys.revokedAt)))
    .returning({ id: adminAccessKeys.id });
  return Boolean(revoked);
}

export function getPublicSiteUrl(request: Request): string {
  const configured = getEnv("PUBLIC_SITE_URL");
  if (configured) {
    try {
      return new URL(configured).origin;
    } catch {
      // Fall through to the request origin when the optional setting is invalid.
    }
  }
  return new URL(request.url).origin;
}
