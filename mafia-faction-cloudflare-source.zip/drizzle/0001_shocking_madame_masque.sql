CREATE TABLE `admin_access_keys` (
	`id` text PRIMARY KEY NOT NULL,
	`key_hash` text NOT NULL,
	`label` text NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`expires_at` text NOT NULL,
	`used_at` text,
	`used_by` text,
	`revoked_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `admin_access_keys_hash_idx` ON `admin_access_keys` (`key_hash`);