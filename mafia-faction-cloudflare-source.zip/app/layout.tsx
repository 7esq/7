import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mafia — Roleplay Syndicate",
  description: "Uma identidade fictícia para experiências de roleplay construídas com respeito, estratégia e presença.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
