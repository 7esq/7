"use client";

import { useState } from "react";
import {
  ArrowUpRight,
  Check,
  ChevronDown,
  Crown,
  Eye,
  Fingerprint,
  LockKeyhole,
  Menu,
  Radio,
  ScanLine,
  ShieldCheck,
  X,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const principles = [
  { number: "01", title: "Respeito antes do status", body: "A hierarquia existe para organizar o RP, nunca para diminuir quem está do outro lado da cena.", icon: ShieldCheck },
  { number: "02", title: "Presença com propósito", body: "Cada entrada, diálogo e decisão deve movimentar a história da cidade com intenção.", icon: Eye },
  { number: "03", title: "Discrição é linguagem", body: "Informação bem guardada, rádio limpa e cenas conduzidas com maturidade deixam o RP mais forte.", icon: LockKeyhole },
];

const codeItems = [
  { title: "Lealdade se prova no detalhe", body: "Pontualidade, comunicação clara e responsabilidade com a cena são a base de qualquer personagem da casa." },
  { title: "A cidade vem antes do ego", body: "Conflitos são construídos para gerar história. O objetivo é criar momentos memoráveis para todos os envolvidos." },
  { title: "A palavra tem peso", body: "Promessas, acordos e decisões são tratados com coerência narrativa, respeito às regras do servidor e consistência." },
];

const roles = [
  { role: "Don", detail: "Direção narrativa", icon: Crown },
  { role: "Consigliere", detail: "Estratégia e mediação", icon: Fingerprint },
  { role: "Caporegime", detail: "Coordenação de núcleos", icon: Radio },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openCode, setOpenCode] = useState(0);
  const closeMenu = () => setMenuOpen(false);

  return (
    <main className="site-shell">
      <div className="ambient-grid" aria-hidden="true" />
      <div className="top-rule" aria-hidden="true" />

      <header className="site-header">
        <a className="brand" href="#top" onClick={closeMenu} aria-label="Mafia, início">
          <span className="brand-mark" aria-hidden="true"><span /><span /><span /></span>
          <span><strong>MAFIA</strong><small>ROLEPLAY SYNDICATE</small></span>
        </a>
        <nav className={menuOpen ? "main-nav is-open" : "main-nav"} aria-label="Navegação principal">
          <a href="#manifesto" onClick={closeMenu}>Manifesto</a>
          <a href="#codigo" onClick={closeMenu}>Código</a>
          <a href="#hierarquia" onClick={closeMenu}>Hierarquia</a>
          <a href="#contato" onClick={closeMenu}>Recrutamento</a>
        </nav>
        <div className="header-actions">
          <span className="online-status"><i /> RP online</span>
          <Button asChild className="header-cta"><a href="#contato">Entrar na casa <ArrowUpRight size={16} /></a></Button>
          <Button variant="ghost" size="icon" className="menu-toggle" onClick={() => setMenuOpen((current) => !current)} aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </Button>
        </div>
      </header>

      <section className="hero section-wrap" id="top">
        <div className="hero-copy">
          <div className="eyebrow reveal delay-1"><span /> Facção fictícia para roleplay</div>
          <h1 className="reveal delay-2">A cidade lembra<em> quem deixa marca.</em></h1>
          <p className="hero-intro reveal delay-3">Uma casa construída em torno de personagem, estratégia e presença. O luxo está no controle da cena — não no excesso.</p>
          <div className="hero-actions reveal delay-4">
            <Button asChild className="button-gold" size="lg"><a href="#manifesto">Conhecer a casa <ArrowUpRight size={18} /></a></Button>
            <a className="text-link" href="#codigo">Ler o código <span>↘</span></a>
          </div>
          <div className="hero-note reveal delay-4"><ScanLine size={15} /><span>MAFIA / DOSSIÊ 001 / REGRAS DE RP EM PRIMEIRO LUGAR</span></div>
        </div>
        <div className="hero-art reveal delay-3" aria-label="Emblema abstrato da Mafia">
          <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
          <div className="art-core"><span className="core-label">M</span><span className="core-line" /><span className="core-sub">EST. 2026</span></div>
          <div className="art-stamp stamp-top">DISCRETION<br />IS POWER</div>
          <div className="art-stamp stamp-bottom">N° 001 — CASA MAFIA</div>
          <div className="art-corner corner-tl" /><div className="art-corner corner-br" />
        </div>
      </section>

      <section className="ticker" aria-label="Princípios da casa"><div className="ticker-track"><span>RESPEITO</span><i /><span>ESTRATÉGIA</span><i /><span>PRESENÇA</span><i /><span>LEALDADE</span><i /><span>RESPEITO</span><i /><span>ESTRATÉGIA</span><i /><span>PRESENÇA</span><i /><span>LEALDADE</span><i /></div></section>

      <section className="manifesto section-wrap" id="manifesto">
        <div className="section-kicker">01 / A casa</div>
        <div className="manifesto-content">
          <div><p className="display-quote">Não somos apenas um grupo. Somos a forma como uma boa história começa.</p><p className="body-copy">A Mafia nasceu para quem entende que o melhor RP não precisa gritar. Ele observa, prepara o terreno e sabe exatamente quando entrar em cena.</p></div>
          <div className="manifesto-side"><div className="side-line" /><span className="side-label">NOTA DO CONSELHO</span><p>“A reputação é feita de pequenas escolhas repetidas até que toda a cidade reconheça seu nome.”</p></div>
        </div>
        <div className="principles-grid">{principles.map((principle) => { const Icon = principle.icon; return <article className="principle-card" key={principle.number}><div className="card-topline"><span>{principle.number}</span><Icon size={19} strokeWidth={1.4} /></div><h2>{principle.title}</h2><p>{principle.body}</p></article>; })}</div>
      </section>

      <section className="code-section section-wrap" id="codigo">
        <div className="section-kicker">02 / O código</div>
        <div className="split-heading"><h2>Elegância na forma.<br /><em>Precisão na atitude.</em></h2><p>O código da casa transforma intenção em comportamento. É simples de entender e difícil de fingir.</p></div>
        <div className="code-layout">
          <div className="code-list">{codeItems.map((item, index) => <div className={openCode === index ? "code-item is-active" : "code-item"} key={item.title}><button type="button" onClick={() => setOpenCode(openCode === index ? -1 : index)} aria-expanded={openCode === index}><span className="code-index">0{index + 1}</span><span>{item.title}</span><ChevronDown size={18} /></button><div className="code-answer"><p>{item.body}</p></div></div>)}</div>
          <div className="code-aside"><div className="aside-icon"><Fingerprint size={34} strokeWidth={1.1} /></div><span className="side-label">ARQUIVO INTERNO</span><p>O personagem é seu. A responsabilidade pela cena é de todos.</p><div className="aside-meta"><span>STATUS</span><strong>APROVADO</strong><Check size={14} /></div></div>
        </div>
      </section>

      <section className="hierarchy section-wrap" id="hierarquia">
        <div className="hierarchy-head"><div className="section-kicker">03 / Hierarquia</div><p>Funções claras para cenas mais vivas.<br />Cada posição carrega uma parte da história.</p></div>
        <div className="role-grid">{roles.map((item, index) => { const Icon = item.icon; return <article className="role-card" key={item.role}><span className="role-number">0{index + 1}</span><Icon size={27} strokeWidth={1.2} /><h3>{item.role}</h3><p>{item.detail}</p></article>; })}</div>
      </section>

      <section className="contact section-wrap" id="contato"><div className="contact-panel"><div><Badge variant="outline" className="gold-badge">RECRUTAMENTO ABERTO</Badge><h2>Seu próximo<br /><em>personagem começa aqui.</em></h2></div><div className="contact-actions"><p>Procuramos presença, criatividade e vontade de construir histórias consistentes dentro do servidor.</p><Button asChild className="button-gold" size="lg"><a href="mailto:recrutamento@mafia-rp.example">Falar com o conselho <ArrowUpRight size={18} /></a></Button></div></div></section>

      <footer className="site-footer section-wrap"><div className="footer-brand"><span className="brand-mark" aria-hidden="true"><span /><span /><span /></span><strong>MAFIA</strong></div><p>Uma identidade fictícia para experiências de roleplay.</p><a className="footer-admin-link" href="/admin">Acesso admin <ArrowUpRight size={13} /></a><span className="footer-code">M / 001 / 2026</span></footer>
    </main>
  );
}
