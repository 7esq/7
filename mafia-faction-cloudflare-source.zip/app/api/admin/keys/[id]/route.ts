import { requireAdminOwner, revokeAdminAccessKey, writeAdminLog } from "@/lib/admin";

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  const auth = await requireAdminOwner(request);
  if (auth.response) return auth.response;

  const { id } = await context.params;
  if (!id || id.length > 80) return Response.json({ error: "Chave inválida." }, { status: 400 });

  try {
    const revoked = await revokeAdminAccessKey(id);
    if (!revoked) return Response.json({ error: "A chave já foi usada, revogada ou não existe." }, { status: 409 });
    await writeAdminLog(auth.user!.id, "revoke_access_key", id, "single_use_key_revoked");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Não foi possível revogar a chave." }, { status: 503 });
  }
}
