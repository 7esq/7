import {
  createAdminAccessKey,
  getPublicSiteUrl,
  listAdminAccessKeys,
  requireAdmin,
  requireAdminOwner,
  writeAdminLog,
} from "@/lib/admin";

export async function GET(request: Request) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;

  try {
    return Response.json({ keys: await listAdminAccessKeys() });
  } catch {
    return Response.json({ error: "Não foi possível carregar as chaves." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  const auth = await requireAdminOwner(request);
  if (auth.response) return auth.response;

  try {
    const payload = await request.json() as { label?: string; expiresInHours?: number };
    const label = payload.label?.trim() ?? "";
    const expiresInHours = Number.isFinite(payload.expiresInHours) ? payload.expiresInHours : 24;
    if (label.length < 2 || label.length > 50) {
      return Response.json({ error: "Dê um nome entre 2 e 50 caracteres." }, { status: 400 });
    }

    const created = await createAdminAccessKey({
      label,
      createdBy: auth.user!.id,
      expiresInHours,
    });
    const accessUrl = new URL(
      "/admin/access?key=" + encodeURIComponent(created.token),
      getPublicSiteUrl(request),
    ).toString();
    const key = {
      id: created.id,
      label: created.label,
      createdBy: created.createdBy,
      createdAt: created.createdAt,
      expiresAt: created.expiresAt,
      usedAt: created.usedAt,
      usedBy: created.usedBy,
      revokedAt: created.revokedAt,
      accessUrl,
    };
    await writeAdminLog(auth.user!.id, "create_access_key", label, "single_use_key_created");
    return Response.json({ key }, { status: 201 });
  } catch {
    return Response.json({ error: "Não foi possível criar a chave." }, { status: 503 });
  }
}
