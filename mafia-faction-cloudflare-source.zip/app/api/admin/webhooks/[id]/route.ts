import { deleteWebhook, getWebhook, requireAdmin, writeAdminLog } from "@/lib/admin";

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;
  const { id } = await context.params;
  try {
    const webhook = await getWebhook(id);
    if (!webhook) return Response.json({ error: "Webhook não encontrado." }, { status: 404 });
    await deleteWebhook(id);
    await writeAdminLog(auth.user!.id, "delete_webhook", webhook.name, "webhook_deleted");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Não foi possível remover o webhook." }, { status: 503 });
  }
}
