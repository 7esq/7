import {
  createWebhook,
  listWebhooks,
  requireAdmin,
  validateDiscordWebhookUrl,
  writeAdminLog,
} from "@/lib/admin";

export async function GET(request: Request) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;
  try {
    return Response.json({ webhooks: await listWebhooks() });
  } catch {
    return Response.json({ error: "Banco de dados ainda não está configurado." }, { status: 503 });
  }
}

export async function POST(request: Request) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;
  try {
    const payload = (await request.json()) as { name?: string; url?: string };
    const name = payload.name?.trim() ?? "";
    const url = validateDiscordWebhookUrl(payload.url ?? "");
    if (name.length < 2 || name.length > 40) return Response.json({ error: "Dê um nome entre 2 e 40 caracteres." }, { status: 400 });
    if (!url) return Response.json({ error: "Use uma URL HTTPS de webhook do Discord válida." }, { status: 400 });

    const webhook = await createWebhook({ name, url, createdBy: auth.user!.id });
    await writeAdminLog(auth.user!.id, "add_webhook", name, "webhook_created");
    return Response.json({ webhook }, { status: 201 });
  } catch {
    return Response.json({ error: "Não foi possível salvar o webhook. Verifique a configuração do banco e do segredo de criptografia." }, { status: 503 });
  }
}
