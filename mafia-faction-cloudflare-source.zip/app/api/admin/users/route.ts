import { listAdminUsers, requireAdmin } from "@/lib/admin";

export async function GET(request: Request) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;

  try {
    return Response.json({ users: await listAdminUsers() });
  } catch {
    return Response.json({ error: "Não foi possível carregar os administradores." }, { status: 503 });
  }
}
