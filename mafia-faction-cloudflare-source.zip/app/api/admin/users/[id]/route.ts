import { listAdminUsers, requireAdminOwner, setAdminUserEnabled, writeAdminLog } from "@/lib/admin";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const auth = await requireAdminOwner(request);
  if (auth.response) return auth.response;
  const { id } = await context.params;
  try {
    const payload = (await request.json()) as { enabled?: boolean };
    if (typeof payload.enabled !== "boolean") return Response.json({ error: "Estado inválido." }, { status: 400 });
    if (id === auth.user!.id && payload.enabled === false) return Response.json({ error: "Você não pode desativar sua própria conta." }, { status: 400 });
    const target = (await listAdminUsers()).find((item) => item.id === id);
    if (!target) return Response.json({ error: "Administrador não encontrado." }, { status: 404 });
    if (target.isOwner && payload.enabled === false) return Response.json({ error: "O proprietário não pode ser desativado." }, { status: 400 });
    const user = await setAdminUserEnabled(id, payload.enabled);
    if (!user) return Response.json({ error: "Administrador não encontrado." }, { status: 404 });
    await writeAdminLog(auth.user!.id, payload.enabled ? "enable_admin" : "disable_admin", user.displayName, "admin_access_changed");
    return Response.json({ user });
  } catch {
    return Response.json({ error: "Não foi possível alterar o acesso." }, { status: 503 });
  }
}
