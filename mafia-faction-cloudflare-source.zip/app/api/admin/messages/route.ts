import {
  decryptSecret,
  getWebhook,
  requireAdmin,
  sendDiscordWebhook,
  writeAdminLog,
} from "@/lib/admin";

export async function POST(request: Request) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;

  let webhookId = "";
  let content = "";
  let username = "";
  try {
    const payload = (await request.json()) as { webhookId?: string; content?: string; username?: string };
    webhookId = payload.webhookId?.trim() ?? "";
    content = payload.content?.trim() ?? "";
    username = payload.username?.trim() ?? "";
    if (!webhookId) return Response.json({ error: "Escolha um webhook." }, { status: 400 });
    if (!content || content.length > 2000) return Response.json({ error: "A mensagem deve ter entre 1 e 2.000 caracteres." }, { status: 400 });

    const webhook = await getWebhook(webhookId);
    if (!webhook) return Response.json({ error: "Webhook não encontrado." }, { status: 404 });
    const targetUrl = await decryptSecret(webhook.urlCiphertext, webhook.urlIv);
    await sendDiscordWebhook(targetUrl, { content, ...(username ? { username: username.slice(0, 80) } : {}) });
    await writeAdminLog(auth.user!.id, "send_message", webhook.name, content.slice(0, 120), "success");
    return Response.json({ ok: true, message: "Mensagem enviada." });
  } catch (error) {
    await writeAdminLog(auth.user!.id, "send_message", webhookId || null, error instanceof Error ? error.message.slice(0, 120) : "discord_request_failed", "error");
    return Response.json({ error: "O Discord não aceitou a mensagem ou o webhook está indisponível." }, { status: 502 });
  }
}
