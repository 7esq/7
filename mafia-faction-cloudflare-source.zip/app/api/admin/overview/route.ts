import { listAdminLogs, listAdminUsers, listWebhooks, requireAdmin } from "@/lib/admin";

export async function GET(request: Request) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;
  try {
    const [webhooks, users, logs] = await Promise.all([listWebhooks(), listAdminUsers(), listAdminLogs(100)]);
    return Response.json({
      stats: {
        webhooks: webhooks.length,
        admins: users.filter((user) => user.enabled).length,
        events: logs.length,
        messages: logs.filter((log) => log.action === "send_message" && log.status === "success").length,
      },
      recent: logs.slice(0, 6),
    });
  } catch {
    return Response.json({ error: "Não foi possível carregar a visão geral." }, { status: 503 });
  }
}
