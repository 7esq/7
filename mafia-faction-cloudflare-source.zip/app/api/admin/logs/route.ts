import { listAdminLogs, requireAdmin } from "@/lib/admin";

export async function GET(request: Request) {
  const auth = await requireAdmin(request);
  if (auth.response) return auth.response;
  try {
    const limit = Number(new URL(request.url).searchParams.get("limit") ?? 40);
    return Response.json({ logs: await listAdminLogs(Number.isFinite(limit) ? limit : 40) });
  } catch {
    return Response.json({ error: "Não foi possível carregar os logs." }, { status: 503 });
  }
}
