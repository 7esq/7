import { redeemAdminKey, redirectToAdmin, sessionCookie, writeAdminLog } from "@/lib/admin";

async function loginWithKey(request: Request, key: string): Promise<Response> {
  if (!key.trim()) return redirectToAdmin(request, "invalid-key");

  try {
    const result = await redeemAdminKey(key);
    if (!result) {
      await writeAdminLog(null, "key_login_denied", "key", "invalid_or_used_key", "denied");
      return redirectToAdmin(request, "invalid-key");
    }

    const response = new Response(null, {
      status: 302,
      headers: { Location: new URL("/admin", request.url).toString() },
    });
    response.headers.append("Set-Cookie", sessionCookie(result.token));
    response.headers.set("Cache-Control", "no-store");
    response.headers.set("Referrer-Policy", "no-referrer");
    return response;
  } catch (error) {
    console.error("Mafia key authentication failed", error instanceof Error ? error.message : "unknown_error");
    return redirectToAdmin(request, "setup-error");
  }
}

export async function POST(request: Request) {
  try {
    const contentType = request.headers.get("content-type") ?? "";
    const key = contentType.includes("application/json")
      ? (await request.json() as { key?: unknown }).key
      : (await request.formData()).get("key");
    return loginWithKey(request, typeof key === "string" ? key : "");
  } catch {
    return redirectToAdmin(request, "invalid-key");
  }
}
