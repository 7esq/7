import { clearSessionCookie, deleteAdminSession } from "@/lib/admin";

export async function POST(request: Request) {
  await deleteAdminSession(request.headers.get("cookie"));
  const response = Response.json({ ok: true });
  response.headers.append("Set-Cookie", clearSessionCookie());
  return response;
}

export async function GET(request: Request) {
  await deleteAdminSession(request.headers.get("cookie"));
  const response = Response.redirect(new URL("/admin", request.url).toString(), 302);
  response.headers.append("Set-Cookie", clearSessionCookie());
  return response;
}
