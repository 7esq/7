"use client";

import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import Link from "next/link";
import {
  Activity,
  AlertCircle,
  ArrowLeft,
  ArrowUpRight,
  Check,
  CircleCheck,
  CirclePlus,
  Copy,
  KeyRound,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  Plus,
  RefreshCw,
  ScrollText,
  Send,
  Settings2,
  ShieldCheck,
  Trash2,
  UsersRound,
  Webhook,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Textarea } from "@/components/ui/textarea";
import type { AdminIdentity } from "@/lib/admin";

type Availability = { key: boolean; encryption: boolean };
type Tab = "overview" | "webhooks" | "messages" | "logs" | "keys" | "access" | "settings";
type WebhookItem = { id: string; name: string; maskedUrl: string; createdAt: string };
type LogItem = { id: string; actorId: string | null; action: string; target: string | null; detail: string; status: string; createdAt: string };
type AdminItem = { id: string; provider: string; providerId: string; email: string | null; displayName: string; enabled: boolean; lastLoginAt: string | null; isOwner: boolean };
type AccessKeyItem = { id: string; label: string; createdBy: string; createdAt: string; expiresAt: string; usedAt: string | null; usedBy: string | null; revokedAt: string | null; accessUrl?: string };
type Stats = { webhooks: number; admins: number; events: number; messages: number };

const navigation: Array<{ id: Tab; label: string; icon: typeof LayoutDashboard }> = [
  { id: "overview", label: "Visão geral", icon: LayoutDashboard },
  { id: "webhooks", label: "Webhooks", icon: Webhook },
  { id: "messages", label: "Mensagens", icon: Send },
  { id: "logs", label: "Logs", icon: ScrollText },
  { id: "keys", label: "Chaves", icon: KeyRound },
  { id: "access", label: "Acessos", icon: UsersRound },
  { id: "settings", label: "Configuração", icon: Settings2 },
];

function errorMessage(error?: string): string | null {
  const messages: Record<string, string> = {
    "invalid-key": "Essa chave é inválida, expirou ou já foi utilizada.",
    "not-configured": "O acesso por chave ainda não foi configurado.",
    "setup-error": "Não foi possível preparar a sessão segura. Tente novamente.",
  };
  return error ? messages[error] ?? "Não foi possível concluir o acesso." : null;
}

export function AdminLogin({ availability, error }: { availability: Availability; error?: string }) {
  const notice = errorMessage(error);
  return (
    <main className="admin-login-shell">
      <div className="admin-login-grid" aria-hidden="true" />
      <Link className="admin-back-link" href="/"><ArrowLeft size={15} /> Voltar para a casa</Link>
      <section className="admin-login-card" aria-labelledby="admin-login-title">
        <div className="admin-login-mark"><span /><span /><span /></div>
        <div className="admin-kicker"><span /> MAFIA / ADMINISTRATIVE ACCESS</div>
        <h1 id="admin-login-title">Acesso<br /><em>restrito.</em></h1>
        <p className="admin-login-lead">Entre com uma chave autorizada para administrar webhooks, mensagens, acessos e registros da casa.</p>
        {notice && <div className="admin-alert error"><AlertCircle size={16} /> {notice}</div>}
        <div className="key-access-panel">
          <div className="key-access-heading">
            <span className="key-access-icon"><KeyRound size={19} /></span>
            <span><strong>Chave privada</strong><small>Entrada por link, sem e-mail ou Discord</small></span>
            <Badge variant="outline" className={availability.key ? "key-configured" : "key-pending"}>{availability.key ? "ATIVA" : "PENDENTE"}</Badge>
          </div>
          <form className="admin-form key-login-form" action="/api/auth/key" method="post">
            <div className="field">
              <Label htmlFor="admin-key">Chave de acesso</Label>
              <Input id="admin-key" name="key" type="password" placeholder="Cole sua chave privada" autoComplete="off" required disabled={!availability.key} />
            </div>
            <Button type="submit" className="admin-primary-button" disabled={!availability.key}><KeyRound size={15} /> Entrar com chave</Button>
          </form>
          <p className="key-login-note"><ShieldCheck size={14} /> Recebeu um link privado? Abra o link diretamente. Chaves de convite são consumidas na primeira entrada.</p>
        </div>
        {!availability.key && <div className="admin-alert warning"><LockKeyhole size={16} /> O proprietário precisa concluir a configuração do segredo de acesso.</div>}
        <div className="admin-login-foot"><ShieldCheck size={14} /><span>As URLs dos webhooks ficam criptografadas e nunca são enviadas para o navegador.</span></div>
      </section>
      <span className="admin-login-code">M / 001 / PRIVATE CONSOLE</span>
    </main>
  );
}

export function AdminDashboard({ user, availability }: { user: AdminIdentity; availability: Availability }) {
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [webhooks, setWebhooks] = useState<WebhookItem[]>([]);
  const [logs, setLogs] = useState<LogItem[]>([]);
  const [admins, setAdmins] = useState<AdminItem[]>([]);
  const [accessKeys, setAccessKeys] = useState<AccessKeyItem[]>([]);
  const [stats, setStats] = useState<Stats>({ webhooks: 0, admins: 0, events: 0, messages: 0 });
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [newWebhookName, setNewWebhookName] = useState("");
  const [newWebhookUrl, setNewWebhookUrl] = useState("");
  const [savingWebhook, setSavingWebhook] = useState(false);
  const [selectedWebhook, setSelectedWebhook] = useState("");
  const [messageContent, setMessageContent] = useState("");
  const [messageUsername, setMessageUsername] = useState("");
  const [sendingMessage, setSendingMessage] = useState(false);
  const [newKeyLabel, setNewKeyLabel] = useState("");
  const [savingKey, setSavingKey] = useState(false);
  const [generatedKeyUrl, setGeneratedKeyUrl] = useState("");

  const notify = (type: "success" | "error", text: string) => {
    setToast({ type, text });
    window.setTimeout(() => setToast(null), 3600);
  };

  async function api<T>(url: string, init?: RequestInit): Promise<T> {
    const response = await fetch(url, {
      ...init,
      headers: {
        ...(init?.body ? { "content-type": "application/json" } : {}),
        ...(init?.headers ?? {}),
      },
    });
    const payload = (await response.json().catch(() => ({}))) as { error?: string } & T;
    if (!response.ok) throw new Error(payload.error || "Ação indisponível.");
    return payload;
  }

  async function refresh() {
    setLoading(true);
    try {
      const [overview, webhookData, logData, adminData, keyData] = await Promise.all([
        api<{ stats: Stats }>("/api/admin/overview"),
        api<{ webhooks: WebhookItem[] }>("/api/admin/webhooks"),
        api<{ logs: LogItem[] }>("/api/admin/logs?limit=60"),
        api<{ users: AdminItem[] }>("/api/admin/users"),
        api<{ keys: AccessKeyItem[] }>("/api/admin/keys"),
      ]);
      setStats(overview.stats);
      setWebhooks(webhookData.webhooks);
      setLogs(logData.logs);
      setAdmins(adminData.users);
      setAccessKeys(keyData.keys);
      if (!selectedWebhook && webhookData.webhooks[0]) setSelectedWebhook(webhookData.webhooks[0].id);
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Não foi possível carregar a dashboard.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(() => void refresh(), 0);
    return () => window.clearTimeout(timer);
    // Initial data is intentionally loaded once for the current admin session.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function addWebhook(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavingWebhook(true);
    try {
      const result = await api<{ webhook: WebhookItem }>("/api/admin/webhooks", { method: "POST", body: JSON.stringify({ name: newWebhookName, url: newWebhookUrl }) });
      setWebhooks((items) => [result.webhook, ...items]);
      setNewWebhookName("");
      setNewWebhookUrl("");
      setSelectedWebhook(result.webhook.id);
      notify("success", "Webhook salvo com segurança.");
      void refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Não foi possível salvar o webhook.");
    } finally {
      setSavingWebhook(false);
    }
  }

  async function removeWebhook(id: string) {
    if (!window.confirm("Remover este webhook da dashboard?")) return;
    try {
      await api("/api/admin/webhooks/" + id, { method: "DELETE" });
      setWebhooks((items) => items.filter((item) => item.id !== id));
      if (selectedWebhook === id) setSelectedWebhook("");
      notify("success", "Webhook removido.");
      void refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Não foi possível remover o webhook.");
    }
  }

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSendingMessage(true);
    try {
      await api("/api/admin/messages", { method: "POST", body: JSON.stringify({ webhookId: selectedWebhook, content: messageContent, username: messageUsername }) });
      setMessageContent("");
      notify("success", "Mensagem enviada para o webhook selecionado.");
      void refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Não foi possível enviar a mensagem.");
    } finally {
      setSendingMessage(false);
    }
  }

  async function createAccessKey(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!user.isOwner) return;
    setSavingKey(true);
    try {
      const result = await api<{ key: AccessKeyItem & { accessUrl: string } }>("/api/admin/keys", {
        method: "POST",
        body: JSON.stringify({ label: newKeyLabel, expiresInHours: 24 }),
      });
      setAccessKeys((items) => [result.key, ...items]);
      setGeneratedKeyUrl(result.key.accessUrl);
      setNewKeyLabel("");
      notify("success", "Chave de uso único criada. Copie o link agora.");
      void refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Não foi possível criar a chave.");
    } finally {
      setSavingKey(false);
    }
  }

  async function copyGeneratedKey() {
    if (!generatedKeyUrl) return;
    try {
      await navigator.clipboard.writeText(generatedKeyUrl);
      notify("success", "Link copiado para a área de transferência.");
    } catch {
      notify("error", "Não foi possível copiar automaticamente. Selecione o link manualmente.");
    }
  }

  async function revokeAccessKey(key: AccessKeyItem) {
    if (!window.confirm("Revogar a chave " + key.label + "?")) return;
    try {
      await api("/api/admin/keys/" + key.id, { method: "DELETE" });
      setAccessKeys((items) => items.map((item) => item.id === key.id ? { ...item, revokedAt: new Date().toISOString() } : item));
      notify("success", "Chave revogada.");
      void refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Não foi possível revogar a chave.");
    }
  }

  async function toggleAdmin(item: AdminItem) {
    try {
      const result = await api<{ user: AdminItem }>("/api/admin/users/" + item.id, { method: "PATCH", body: JSON.stringify({ enabled: !item.enabled }) });
      setAdmins((items) => items.map((current) => current.id === item.id ? result.user : current));
      notify("success", result.user.enabled ? "Acesso reativado." : "Acesso desativado.");
      void refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Não foi possível alterar o acesso.");
    }
  }

  async function logout() {
    await fetch("/api/auth/signout", { method: "POST" });
    window.location.href = "/admin";
  }

  const currentTab = navigation.find((item) => item.id === activeTab) ?? navigation[0];
  const activeWebhookName = useMemo(() => webhooks.find((item) => item.id === selectedWebhook)?.name ?? "Nenhum webhook selecionado", [webhooks, selectedWebhook]);

  return (
    <main className="admin-shell">
      <aside className={mobileNavOpen ? "admin-sidebar is-open" : "admin-sidebar"}>
        <div className="admin-side-top"><Link className="admin-brand" href="/"><span className="brand-mark" aria-hidden="true"><span /><span /><span /></span><span><strong>MAFIA</strong><small>ADMIN CONSOLE</small></span></Link><Button variant="ghost" size="icon" className="admin-close-nav" onClick={() => setMobileNavOpen(false)} aria-label="Fechar navegação">×</Button></div>
        <div className="admin-side-label">WORKSPACE / 001</div>
        <nav className="admin-nav" aria-label="Navegação da dashboard">{navigation.map((item) => { const Icon = item.icon; return <button key={item.id} className={activeTab === item.id ? "is-active" : ""} onClick={() => { setActiveTab(item.id); setMobileNavOpen(false); }}><Icon size={17} /><span>{item.label}</span>{item.id === "logs" && logs.length > 0 && <i>{Math.min(logs.length, 99)}</i>}</button>; })}</nav>
        <div className="admin-sidebar-bottom"><div className="admin-user-mini"><span className="user-initial">{user.displayName.slice(0, 1).toUpperCase()}</span><span><strong>{user.displayName}</strong><small>{user.isOwner ? "owner / controle total" : "chave / admin"}</small></span><CircleCheck size={14} /></div><button className="admin-logout" onClick={() => void logout()}><LogOut size={15} /> Encerrar sessão</button></div>
      </aside>
      <div className="admin-main">
        <header className="admin-topbar"><Button variant="ghost" size="icon" className="admin-mobile-menu" onClick={() => setMobileNavOpen(true)} aria-label="Abrir navegação">☰</Button><div className="admin-breadcrumb"><span>MAFIA</span><i>/</i><strong>{currentTab.label}</strong></div><div className="admin-top-actions"><span className="admin-live"><i /> SISTEMA ONLINE</span><Link href="/" className="admin-site-link">Ver site <ArrowUpRight size={15} /></Link></div></header>
        <section className="admin-content">
          <div className="admin-page-heading"><div><div className="admin-kicker"><span /> CONTROL ROOM / {activeTab === "overview" ? "OVERVIEW" : currentTab.label.toUpperCase()}</div><h1>{activeTab === "overview" ? <>Bom te ver,<br /><em>{user.displayName.split(" ")[0]}.</em></> : currentTab.label}</h1><p>{activeTab === "overview" ? "Acompanhe a operação e mantenha a comunicação da casa sob controle." : tabDescription(activeTab)}</p></div><Button variant="outline" className="admin-refresh" onClick={() => void refresh()} disabled={loading}><RefreshCw size={15} className={loading ? "is-spinning" : ""} /> Atualizar dados</Button></div>
          {activeTab === "overview" && <Overview stats={stats} logs={logs} webhooks={webhooks} isOwner={user.isOwner} setActiveTab={setActiveTab} />}
          {activeTab === "webhooks" && <WebhooksView webhooks={webhooks} name={newWebhookName} url={newWebhookUrl} setName={setNewWebhookName} setUrl={setNewWebhookUrl} saving={savingWebhook} onAdd={addWebhook} onRemove={removeWebhook} />}
          {activeTab === "messages" && <MessagesView webhooks={webhooks} selectedWebhook={selectedWebhook} setSelectedWebhook={setSelectedWebhook} activeWebhookName={activeWebhookName} content={messageContent} username={messageUsername} setContent={setMessageContent} setUsername={setMessageUsername} sending={sendingMessage} onSend={sendMessage} />}
          {activeTab === "logs" && <LogsView logs={logs} />}
          {activeTab === "keys" && <KeyView keys={accessKeys} isOwner={user.isOwner} label={newKeyLabel} setLabel={setNewKeyLabel} saving={savingKey} generatedUrl={generatedKeyUrl} onCreate={createAccessKey} onCopy={copyGeneratedKey} onRevoke={revokeAccessKey} />}
          {activeTab === "access" && <AccessView admins={admins} currentUserId={user.id} isOwner={user.isOwner} onOpenKeys={() => setActiveTab("keys")} onToggle={toggleAdmin} />}
          {activeTab === "settings" && <SettingsView availability={availability} user={user} />}
        </section>
      </div>
      {toast && <div className={"admin-toast " + toast.type}><span>{toast.type === "success" ? <Check size={15} /> : <AlertCircle size={15} />}</span>{toast.text}</div>}
    </main>
  );
}

function tabDescription(tab: Tab) {
  const descriptions: Record<Tab, string> = {
    overview: "",
    webhooks: "Cadastre e organize os destinos de comunicação da casa.",
    messages: "Envie uma mensagem para um destino específico sem expor a URL.",
    logs: "Um histórico objetivo das ações administrativas e seus resultados.",
    keys: "Crie links de entrada temporários e acompanhe o ciclo de cada chave.",
    access: "Veja quem entrou por chave e pause acessos quando necessário.",
    settings: "Status da autenticação por chave, proteção de segredos e identidade da console.",
  };
  return descriptions[tab];
}

function Overview({ stats, logs, webhooks, isOwner, setActiveTab }: { stats: Stats; logs: LogItem[]; webhooks: WebhookItem[]; isOwner: boolean; setActiveTab: (tab: Tab) => void }) {
  return <>
    <div className="admin-stat-grid"><StatCard label="Webhooks ativos" value={stats.webhooks} detail="Destinos protegidos" icon={Webhook} /><StatCard label="Mensagens enviadas" value={stats.messages} detail="Ações concluídas" icon={Send} /><StatCard label="Admins ativos" value={stats.admins} detail="Contas autorizadas" icon={UsersRound} /><StatCard label="Eventos registrados" value={stats.events} detail="Últimos 100 eventos" icon={Activity} /></div>
    <div className="admin-overview-grid"><section className="admin-panel recent-panel"><div className="panel-heading"><div><span className="panel-eyebrow">ATIVIDADE RECENTE</span><h2>Últimos movimentos</h2></div><button onClick={() => setActiveTab("logs")}>Ver todos <ArrowUpRight size={14} /></button></div>{logs.length ? <div className="activity-list">{logs.slice(0, 5).map((log) => <ActivityRow key={log.id} log={log} />)}</div> : <EmptyState icon={ScrollText} title="Nenhum evento ainda" body="As ações da console aparecerão aqui." />}</section><section className="admin-panel quick-panel"><div className="panel-heading"><div><span className="panel-eyebrow">ATALHOS</span><h2>Ações rápidas</h2></div><CirclePlus size={18} /></div><button onClick={() => setActiveTab("messages")}><span className="quick-icon"><Send size={17} /></span><span><strong>Enviar mensagem</strong><small>Escolha um webhook e publique</small></span><ArrowUpRight size={15} /></button><button onClick={() => setActiveTab("webhooks")}><span className="quick-icon"><Webhook size={17} /></span><span><strong>Adicionar webhook</strong><small>Proteja um novo destino</small></span><ArrowUpRight size={15} /></button><button onClick={() => setActiveTab(isOwner ? "keys" : "access")}><span className="quick-icon"><KeyRound size={17} /></span><span><strong>{isOwner ? "Gerar chave de entrada" : "Ver acessos"}</strong><small>{isOwner ? "Link temporário de uso único" : "Status da sua entrada"}</small></span><ArrowUpRight size={15} /></button></section></div>
    <div className="admin-signal-row"><div><span className="signal-dot" /><strong>Proteção operacional ativa</strong><span>URLs criptografadas no servidor · autenticação por chave · trilha de auditoria</span></div><span>{webhooks.length} destino{webhooks.length === 1 ? "" : "s"} configurado{webhooks.length === 1 ? "" : "s"}</span></div>
  </>;
}

function StatCard({ label, value, detail, icon: Icon }: { label: string; value: number; detail: string; icon: typeof Webhook }) {
  return <article className="admin-stat-card"><div className="stat-icon"><Icon size={18} /></div><span>{label}</span><strong>{value.toString().padStart(2, "0")}</strong><small>{detail}</small></article>;
}

function ActivityRow({ log }: { log: LogItem }) {
  return <div className="activity-row"><span className={"activity-status " + log.status}><Check size={12} /></span><span className="activity-copy"><strong>{actionLabel(log.action)}</strong><small>{log.target ?? "Sistema"} · {formatDate(log.createdAt)}</small></span><span className="activity-arrow">↗</span></div>;
}

function EmptyState({ icon: Icon, title, body }: { icon: typeof ScrollText; title: string; body: string }) {
  return <div className="admin-empty"><Icon size={22} /><strong>{title}</strong><span>{body}</span></div>;
}

function WebhooksView({ webhooks, name, url, setName, setUrl, saving, onAdd, onRemove }: { webhooks: WebhookItem[]; name: string; url: string; setName: (value: string) => void; setUrl: (value: string) => void; saving: boolean; onAdd: (event: FormEvent<HTMLFormElement>) => void; onRemove: (id: string) => void }) {
  return <div className="admin-detail-grid"><section className="admin-panel form-panel"><div className="panel-heading"><div><span className="panel-eyebrow">NOVO DESTINO</span><h2>Adicionar webhook</h2></div><Webhook size={19} /></div><p className="panel-intro">Dê um nome reconhecível ao destino. A URL será criptografada antes de ser salva.</p><form className="admin-form" onSubmit={onAdd}><div className="field"><Label htmlFor="webhook-name">Nome interno</Label><Input id="webhook-name" value={name} onChange={(event) => setName(event.target.value)} placeholder="ex.: avisos" maxLength={40} required /></div><div className="field"><Label htmlFor="webhook-url">URL do webhook Discord</Label><Input id="webhook-url" type="url" value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://discord.com/api/webhooks/..." required /></div><Button type="submit" className="admin-primary-button" disabled={saving}>{saving ? <RefreshCw size={15} className="is-spinning" /> : <Plus size={15} />} {saving ? "Salvando..." : "Salvar destino"}</Button></form></section><section className="admin-panel list-panel"><div className="panel-heading"><div><span className="panel-eyebrow">DESTINOS SALVOS</span><h2>Seus webhooks</h2></div><Badge variant="outline" className="count-badge">{webhooks.length.toString().padStart(2, "0")}</Badge></div>{webhooks.length ? <div className="webhook-list">{webhooks.map((webhook) => <div className="webhook-row" key={webhook.id}><div className="webhook-symbol"><Webhook size={17} /></div><div className="webhook-copy"><strong>{webhook.name}</strong><span>{webhook.maskedUrl}</span><small>Adicionado {formatDate(webhook.createdAt)}</small></div><button className="icon-danger" onClick={() => onRemove(webhook.id)} aria-label={"Remover " + webhook.name}><Trash2 size={15} /></button></div>)}</div> : <EmptyState icon={Webhook} title="Nenhum webhook" body="Adicione seu primeiro destino ao lado." />}</section></div>;
}

function MessagesView({ webhooks, selectedWebhook, setSelectedWebhook, activeWebhookName, content, username, setContent, setUsername, sending, onSend }: { webhooks: WebhookItem[]; selectedWebhook: string; setSelectedWebhook: (value: string) => void; activeWebhookName: string; content: string; username: string; setContent: (value: string) => void; setUsername: (value: string) => void; sending: boolean; onSend: (event: FormEvent<HTMLFormElement>) => void }) {
  return <div className="admin-detail-grid message-grid"><section className="admin-panel form-panel"><div className="panel-heading"><div><span className="panel-eyebrow">COMUNICAÇÃO</span><h2>Nova mensagem</h2></div><Send size={19} /></div><p className="panel-intro">A mensagem sai pelo servidor. O endereço real do webhook não aparece nesta tela.</p><form className="admin-form" onSubmit={onSend}><div className="field"><Label htmlFor="message-webhook">Escolha um webhook</Label><NativeSelect id="message-webhook" className="admin-native-select" value={selectedWebhook} onChange={(event) => setSelectedWebhook(event.target.value)} disabled={!webhooks.length} required><NativeSelectOption value="">{webhooks.length ? "Selecione um destino" : "Nenhum webhook cadastrado"}</NativeSelectOption>{webhooks.map((webhook) => <NativeSelectOption key={webhook.id} value={webhook.id}>{webhook.name}</NativeSelectOption>)}</NativeSelect></div><div className="field"><Label htmlFor="message-content">Mensagem</Label><Textarea id="message-content" value={content} onChange={(event) => setContent(event.target.value)} placeholder="Escreva a mensagem que a casa precisa comunicar..." maxLength={2000} required /><small className="field-hint">{content.length} / 2.000 caracteres</small></div><div className="field"><Label htmlFor="message-username">Nome exibido <span>(opcional)</span></Label><Input id="message-username" value={username} onChange={(event) => setUsername(event.target.value)} placeholder="Mafia Control" maxLength={80} /></div><Button type="submit" className="admin-primary-button" disabled={sending || !webhooks.length}>{sending ? <RefreshCw size={15} className="is-spinning" /> : <Send size={15} />} {sending ? "Enviando..." : "Enviar mensagem"}</Button></form></section><section className="admin-panel preview-panel"><div className="panel-heading"><div><span className="panel-eyebrow">PRÉVIA DE DESTINO</span><h2>{activeWebhookName}</h2></div><CircleCheck size={18} /></div><div className="message-preview"><div className="preview-top"><span className="preview-avatar">M</span><span><strong>{username || "Mafia Control"}</strong><small>agora · webhook</small></span></div><p>{content || "Sua mensagem aparecerá aqui antes do envio."}</p></div><div className="preview-note"><ShieldCheck size={15} /><span>Somente o destino nomeado será utilizado nesta ação.</span></div></section></div>;
}

function KeyView({ keys, isOwner, label, setLabel, saving, generatedUrl, onCreate, onCopy, onRevoke }: { keys: AccessKeyItem[]; isOwner: boolean; label: string; setLabel: (value: string) => void; saving: boolean; generatedUrl: string; onCreate: (event: FormEvent<HTMLFormElement>) => void; onCopy: () => void; onRevoke: (key: AccessKeyItem) => void }) {
  return <div className="admin-detail-grid key-grid"><section className="admin-panel form-panel key-create-panel"><div className="panel-heading"><div><span className="panel-eyebrow">CONVITE TEMPORÁRIO</span><h2>Gerar chave</h2></div><KeyRound size={19} /></div><p className="panel-intro">Crie um link privado para outro administrador. Ele vale por 24 horas e só pode abrir uma sessão.</p><form className="admin-form" onSubmit={onCreate}><div className="field"><Label htmlFor="key-label">Nome do convite</Label><Input id="key-label" value={label} onChange={(event) => setLabel(event.target.value)} placeholder="ex.: Chefe de avisos" maxLength={50} required disabled={!isOwner} /><small className="field-hint">Use um nome que ajude a reconhecer quem recebeu.</small></div><Button type="submit" className="admin-primary-button" disabled={!isOwner || saving}>{saving ? <RefreshCw size={15} className="is-spinning" /> : <Plus size={15} />} {saving ? "Gerando..." : "Criar chave de uso único"}</Button></form>{!isOwner && <div className="permission-note"><LockKeyhole size={15} /><span>Somente o proprietário pode gerar ou revogar convites.</span></div>}{generatedUrl && <div className="generated-key-card"><div className="generated-key-heading"><span><Check size={14} /></span><div><strong>Link criado</strong><small>Copie agora; por segurança, ele não volta a aparecer depois.</small></div></div><div className="generated-key-row"><Input value={generatedUrl} readOnly aria-label="Link da chave de uso único" /><button type="button" onClick={onCopy} aria-label="Copiar link da chave"><Copy size={15} /> Copiar</button></div></div>}</section><section className="admin-panel list-panel key-list-panel"><div className="panel-heading"><div><span className="panel-eyebrow">CICLO DE ACESSO</span><h2>Chaves emitidas</h2></div><Badge variant="outline" className="count-badge">{keys.length.toString().padStart(2, "0")}</Badge></div>{keys.length ? <div className="key-list">{keys.map((key) => <KeyRow key={key.id} item={key} isOwner={isOwner} onRevoke={onRevoke} />)}</div> : <EmptyState icon={KeyRound} title="Nenhuma chave emitida" body="O primeiro convite criado aparecerá aqui." />}</section></div>;
}

function KeyRow({ item, isOwner, onRevoke }: { item: AccessKeyItem; isOwner: boolean; onRevoke: (key: AccessKeyItem) => void }) {
  const state = getKeyState(item);
  const stateLabel = state === "available" ? "Disponível" : state === "used" ? "Usada" : state === "revoked" ? "Revogada" : "Expirada";
  return <div className="key-row"><span className="key-symbol"><KeyRound size={16} /></span><div className="key-copy"><strong>{item.label}</strong><span>Uso único · expira {formatDate(item.expiresAt)}</span><small>{item.usedAt ? "Entrada registrada " + formatDate(item.usedAt) : "Criada " + formatDate(item.createdAt)}</small></div><span className={"key-state " + state}>{stateLabel}</span>{state === "available" && isOwner && <button className="icon-danger" onClick={() => onRevoke(item)} aria-label={"Revogar " + item.label}><Trash2 size={15} /></button>}</div>;
}

function getKeyState(item: AccessKeyItem): "available" | "used" | "revoked" | "expired" {
  if (item.revokedAt) return "revoked";
  if (item.usedAt) return "used";
  if (new Date(item.expiresAt).getTime() <= Date.now()) return "expired";
  return "available";
}

function LogsView({ logs }: { logs: LogItem[] }) {
  return <section className="admin-panel logs-panel"><div className="panel-heading"><div><span className="panel-eyebrow">AUDITORIA</span><h2>Registro de atividade</h2></div><Badge variant="outline" className="count-badge">{logs.length.toString().padStart(2, "0")} eventos</Badge></div>{logs.length ? <div className="logs-table-wrap"><table className="logs-table"><thead><tr><th>Evento</th><th>Destino</th><th>Resultado</th><th>Quando</th></tr></thead><tbody>{logs.map((log) => <tr key={log.id}><td><span className={"table-status " + log.status}><i />{actionLabel(log.action)}</span></td><td><strong>{log.target || "Sistema"}</strong><small>{log.detail}</small></td><td><Badge variant="outline" className={log.status === "success" ? "status-badge success" : "status-badge error"}>{log.status === "success" ? "Concluído" : log.status === "denied" ? "Negado" : "Falhou"}</Badge></td><td>{formatDate(log.createdAt)}</td></tr>)}</tbody></table></div> : <EmptyState icon={ScrollText} title="Sem registros" body="A trilha de auditoria será preenchida conforme a console for usada." />}</section>;
}

function AccessView({ admins, currentUserId, isOwner, onOpenKeys, onToggle }: { admins: AdminItem[]; currentUserId: string; isOwner: boolean; onOpenKeys: () => void; onToggle: (item: AdminItem) => void }) {
  const keyAdmins = admins.filter((item) => item.provider === "key");
  return <div className="admin-detail-grid access-grid"><section className="admin-panel form-panel access-info-panel"><div className="panel-heading"><div><span className="panel-eyebrow">ENTRADA DA CASA</span><h2>Acesso por chave</h2></div><UsersRound size={19} /></div><p className="panel-intro">Cada administrador entra através de um link privado. Chaves de convite são de uso único; depois da entrada, você pode pausar a sessão por aqui.</p><div className="access-flow"><div><span>01</span><strong>Gerar</strong><small>Crie um convite nomeado</small></div><div><span>02</span><strong>Enviar</strong><small>Compartilhe o link em privado</small></div><div><span>03</span><strong>Controlar</strong><small>Pause acessos quando precisar</small></div></div><Button type="button" className="admin-primary-button" onClick={onOpenKeys}><KeyRound size={15} /> Abrir gerador de chaves</Button>{!isOwner && <div className="permission-note"><LockKeyhole size={15} /><span>Você pode consultar seu acesso, mas só o proprietário gerencia convites.</span></div>}</section><section className="admin-panel list-panel"><div className="panel-heading"><div><span className="panel-eyebrow">LISTA DE ACESSO</span><h2>Administradores</h2></div><Badge variant="outline" className="count-badge">{keyAdmins.length.toString().padStart(2, "0")}</Badge></div>{keyAdmins.length ? <div className="admin-list">{keyAdmins.map((item) => <div className="admin-row" key={item.id}><span className="admin-avatar">{item.displayName.slice(0, 1).toUpperCase()}</span><div className="admin-row-copy"><strong>{item.displayName}{item.isOwner && <small className="admin-owner-badge">Dono</small>}{item.id === currentUserId && <small>Você</small>}</strong><span>entrada por chave · sessão persistente</span><small>{item.lastLoginAt ? "Último login " + formatDate(item.lastLoginAt) : "Nunca entrou"}</small></div><button className={item.enabled ? "access-toggle is-on" : "access-toggle"} onClick={() => onToggle(item)} disabled={!isOwner || item.id === currentUserId || item.isOwner} aria-label={item.isOwner ? "O proprietário não pode ser desativado" : item.enabled ? "Desativar " + item.displayName : "Ativar " + item.displayName}><i /></button></div>)}</div> : <EmptyState icon={UsersRound} title="Nenhum administrador" body="Gere a primeira chave temporária para criar um acesso." />}</section></div>;
}

function SettingsView({ availability, user }: { availability: Availability; user: AdminIdentity }) {
  return <div className="settings-layout"><section className="admin-panel settings-panel"><div className="panel-heading"><div><span className="panel-eyebrow">IDENTIDADE ATUAL</span><h2>Sessão protegida</h2></div><ShieldCheck size={19} /></div><div className="identity-card"><span className="admin-avatar large">{user.displayName.slice(0, 1).toUpperCase()}</span><div><strong>{user.displayName}</strong><span>{user.email || "Acesso por chave"}</span><small>Provedor: chave · sessão ativa</small></div><CircleCheck size={17} /></div><div className="settings-note"><LockKeyhole size={16} /><span>A sessão usa cookie HttpOnly, Secure e expira automaticamente após sete dias.</span></div></section><section className="admin-panel settings-panel"><div className="panel-heading"><div><span className="panel-eyebrow">SEGURANÇA</span><h2>Status de configuração</h2></div><Settings2 size={19} /></div><div className="integration-list"><IntegrationRow label="Acesso por chave" ready={availability.key} /><IntegrationRow label="Criptografia de webhooks" ready={availability.encryption} /><IntegrationRow label="Sessões persistentes" ready={true} /></div><div className="settings-note"><AlertCircle size={16} /><span>Links de convite são exibidos somente no momento da criação e nunca ficam salvos em texto aberto.</span></div></section></div>;
}

function IntegrationRow({ label, ready }: { label: string; ready: boolean }) {
  return <div className="integration-row"><span className={ready ? "integration-icon ready" : "integration-icon"}>{ready ? <Check size={14} /> : <LockKeyhole size={14} />}</span><strong>{label}</strong><span className={ready ? "integration-status ready" : "integration-status"}>{ready ? "ATIVO" : "PENDENTE"}</span></div>;
}

function actionLabel(action: string) {
  const labels: Record<string, string> = {
    key_login: "Login por chave",
    key_login_denied: "Chave recusada",
    create_access_key: "Chave criada",
    revoke_access_key: "Chave revogada",
    login: "Login administrativo",
    login_denied: "Login negado",
    add_webhook: "Webhook adicionado",
    delete_webhook: "Webhook removido",
    send_message: "Mensagem enviada",
    enable_admin: "Acesso reativado",
    disable_admin: "Acesso desativado",
  };
  return labels[action] ?? action.replaceAll("_", " ");
}

function formatDate(value: string) {
  try {
    return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(new Date(value));
  } catch {
    return value;
  }
}
