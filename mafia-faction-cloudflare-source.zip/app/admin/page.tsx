import { headers } from "next/headers";

import { getAdminUserFromCookie, getAuthAvailability } from "@/lib/admin";
import { AdminDashboard, AdminLogin } from "./admin-client";

export const dynamic = "force-dynamic";

type AdminPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function AdminPage({ searchParams }: AdminPageProps) {
  const requestHeaders = await headers();
  const user = await getAdminUserFromCookie(requestHeaders.get("cookie"));
  const query = await searchParams;
  const error = typeof query?.error === "string" ? query.error : undefined;
  const availability = getAuthAvailability();

  if (!user) return <AdminLogin availability={availability} error={error} />;
  return <AdminDashboard user={user} availability={availability} />;
}
