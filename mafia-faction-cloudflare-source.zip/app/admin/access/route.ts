import { redeemAdminKey, redirectToAdmin, sessionCookie, writeAdminLog } from "@/lib/admin";

export async function GET(request: Request) {
  const key = new URL(request.url).searchParams.get("key")?.trim() ?? "";
  if (!key) return redirectToAdmin(request, "invalid-key");

  try {
    const result = await redeemAdminKey(key);
    if (!result) {
      await writeAdminLog(null, "key_login_denied", "key", "invalid_or_used_key", "denied");
      return redirectToAdmin(request, "invalid-key");
    }

    const response = new Response(null, {
      status: 302,
      headers: { Location: new URL("/admin", request.url).toString() },
    });
    response.headers.append("Set-Cookie", sessionCookie(result.token));
    response.headers.set("Cache-Control", "no-store");
    response.headers.set("Referrer-Policy", "no-referrer");
    return response;
  } catch (error) {
    console.error("Mafia owner link authentication failed", error instanceof Error ? error.message : "unknown_error");
    return redirectToAdmin(request, "setup-error");
  }
}
